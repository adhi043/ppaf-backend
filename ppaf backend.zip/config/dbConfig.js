module.exports={
    HOST:'localhost',
    PORT:'8000',
    USER:'admscciorg',
    PASSWORD:'Lighthouseteam098',
    DB:'admsccio_daak_db',
    dialect:'mysql',
    KEY_NAME:'janwarMA5',

    pool:{
        max:5,
        min:0,
        idle:10000,
        acquire:30000
    }
}